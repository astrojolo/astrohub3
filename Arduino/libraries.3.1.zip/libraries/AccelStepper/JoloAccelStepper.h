#ifndef _JoloAccelStepper_h
#define _JoloAccelStepper_h

#include "AccelStepper.h"

class JoloAccelStepper : public AccelStepper
{
    public:
    JoloAccelStepper(uint8_t interface, uint8_t pin1, uint8_t pin2, uint8_t pin3, uint8_t pin4, bool enable, byte bipolar);
	void setMode(byte value);	// 0 - uni, 1 - bi
    
    protected:
    void step0(long step);
	void setOutputPins(uint8_t mask);
	
	private:
	byte _mode;
	byte _uniSteps[8];
    byte _biSteps[8]; 
    
};


JoloAccelStepper::JoloAccelStepper(uint8_t interface, uint8_t pin1, uint8_t pin2, uint8_t pin3, uint8_t pin4, bool enable, byte mode)
{
	Serial.println("aa " + pin1 + pin2 + pin3 + pin4);
    AccelStepper(interface, pin1, pin2, pin3, pin4, enable);
	_mode = mode;
	_uniSteps[0] = 0b0001;
	_uniSteps[1] = 0b0011;
	_uniSteps[2] = 0b0010;
	_uniSteps[3] = 0b0110;
	_uniSteps[4] = 0b0100;
	_uniSteps[5] = 0b1100;
	_uniSteps[6] = 0b1000;
	_uniSteps[7] = 0b1001;
	_biSteps[0] = 0b0001;
	_biSteps[1] = 0b0101;
	_biSteps[2] = 0b0100;
	_biSteps[3] = 0b0110;
	_biSteps[4] = 0b0010;
	_biSteps[5] = 0b1010;
	_biSteps[6] = 0b1000;
	_biSteps[7] = 0b1001;
}

void JoloAccelStepper::setMode(byte value) {_mode = value;}



// 0 pin step function (ie for functional usage)
void JoloAccelStepper::step0(long step)
{
	byte index = step & 0x7;
	if(_mode == 1)
		setOutputPins(_biSteps[index]);
	else
		setOutputPins(_uniSteps[index]);
}

// You might want to override this to implement eg serial output
// bit 0 of the mask corresponds to _pin[0]
// bit 1 of the mask corresponds to _pin[1]
// ....
void JoloAccelStepper::setOutputPins(uint8_t mask)
{
    uint8_t numpins = 2;
    if (_interface == FULL4WIRE || _interface == HALF4WIRE || _interface == FUNCTION)
		numpins = 4;
    else if (_interface == FULL3WIRE || _interface == HALF3WIRE)
		numpins = 3;
    uint8_t i;
    //for (i = 0; i < numpins; i++)
	//digitalWrite(_pin[i], (mask & (1 << i)) ? (HIGH ^ _pinInverted[i]) : (LOW ^ _pinInverted[i]));

    for (i = 0; i < numpins; i++) 
	{
		Serial.print(_pin[i]);
		Serial.print(" - ");
		Serial.print((mask & (1 << i)) ? (HIGH ^ _pinInverted[i]) : (LOW ^ _pinInverted[i]));
		Serial.print("..");
		digitalWrite(_pin[i], (mask & (1 << i)) ? (HIGH ^ _pinInverted[i]) : (LOW ^ _pinInverted[i]));
	}
	Serial.println(" ");
}


#endif
